package com.toptop.jetonsatisi

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val whatsappPhone = "994773247506"

    private val packages = listOf(
        Triple("70K", "5 AZN", "🔥 Başlanğıc"),
        Triple("100K", "7 AZN", "⭐ Populyar"),
        Triple("500K", "30 AZN", "💎 Böyük Paket"),
        Triple("1M", "50 AZN", "👑 VIP Paket")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val container = findViewById<LinearLayout>(R.id.packageContainer)

        packages.forEach { (amount, price, label) ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(16, 16, 16, 16)
                setBackgroundResource(R.drawable.card_bg)
            }

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }

            val tag = TextView(this).apply {
                text = label
                setTextColor(Color.rgb(246, 196, 83))
                textSize = 12f
            }

            val title = TextView(this).apply {
                text = "🪙 $amount Jeton"
                setTextColor(Color.WHITE)
                textSize = 21f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            val priceView = TextView(this).apply {
                text = price
                setTextColor(Color.rgb(246, 196, 83))
                textSize = 18f
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            info.addView(tag)
            info.addView(title)
            info.addView(priceView)

            val buy = Button(this).apply {
                text = "AL"
                textAllCaps = false
                setTextColor(Color.rgb(17, 17, 17))
                setBackgroundResource(R.drawable.button_gold)
                setOnClickListener { orderOnWhatsApp(amount, price) }
            }

            card.addView(info)
            card.addView(buy)

            val params = LinearLayout.LayoutParams(-1, -2).apply {
                setMargins(0, 8, 0, 8)
            }
            container.addView(card, params)
        }

        findViewById<Button>(R.id.contactButton).setOnClickListener {
            openWhatsApp("Salam, TopTop Jeton Satışı haqqında məlumat almaq istəyirəm.")
        }
    }

    private fun orderOnWhatsApp(amount: String, price: String) {
        openWhatsApp("Salam, $amount Jeton ($price) almaq istəyirəm.")
    }

    private fun openWhatsApp(message: String) {
        val url = "https://wa.me/$whatsappPhone?text=${Uri.encode(message)}"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$whatsappPhone")))
        }
    }
}
