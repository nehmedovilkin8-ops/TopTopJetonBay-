# TopTop Jeton Satışı — Android

Bu proje telefonla GitHub üzerinden APK üretmek üçün hazırlanıb.

## Paketlər
- 70K — 5 AZN
- 100K — 7 AZN
- 500K — 30 AZN
- 1M — 50 AZN

WhatsApp: +994 77 324 75 06

## APK-ni telefondan çıxarma
1. GitHub-da yeni repository yaradın.
2. Bu layihənin bütün fayllarını repository-nin əsas qovluğuna yükləyin.
3. `.github/workflows/build-apk.yml` faylının da yükləndiyinə əmin olun.
4. GitHub-da **Actions** bölməsinə girin.
5. **Build APK** workflow-unun tamamlanmasını gözləyin.
6. Workflow nəticəsində **Artifacts** bölməsində `TopTopJetonSatisi-APK` faylı görünəcək.
7. APK-ni telefona endirib quraşdırın.

Qeyd: Bu debug APK test və şəxsi istifadə üçündür. Play Store üçün ayrıca imzalama və release build lazımdır.
